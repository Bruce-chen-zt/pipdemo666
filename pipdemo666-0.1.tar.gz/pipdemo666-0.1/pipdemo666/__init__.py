def start():
    print("import successful 春眠不觉晓，处处蚊子咬")