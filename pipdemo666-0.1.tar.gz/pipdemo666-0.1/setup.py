from setuptools import setup
setup(name='pipdemo666',
      version='0.1',
      description='clinical trial information retriver',
      url='https://github.com/Bruce-chen-zt/pipdemo666',
      author='Bruce',
      author_email='chenzetao2021@163.com',
      license='MIT',
      packages=['pipdemo666'],
      zip_safe=False)